//
//		          Programming Assignment #1
//
//			        Victor Zordan
//
//
//
/***************************************************************************/

/* Include needed files */
#ifdef __APPLE__
#include <OpenGL/gl.h>
#include <OpenGL/glu.h>
#else
#include <GL/gl.h>
#include <GL/glu.h>
#endif
#include <GLUT/glut.h> // The GL Utility Toolkit (Glut) Header
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <vector>
#include <iostream>
// #include "Point.h"
#include "Line.h"

#define WIDTH 500
#define HEIGHT 500

int x_last, y_last;
std::vector<Point> points; //store the history point
bool Line::isDrawed = false;

/***************************************************************************/

void write_pixel(int x, int y, double intensity)
/* Turn on the pixel found at x,y */
{

	glColor3f(intensity, intensity, intensity);
	glBegin(GL_POINTS);
	glVertex3i(x, y, 0);
	glEnd();
}
//***************************************************************************/
void dda(int x1, int x2, int y1, int y2){
	int dx = x2 - x1; // changes for x between two points
	int dy = y2 - y1; // changes for y between two points
	int steps = 0;
	float x_inc = 0, y_inc = 0; // mark the increment of x and y for each change.
	float x=x1, y=y1;// the point of x and y after each changes.

	if (abs(dx)>=abs(dy))
	{
		steps = abs(dx);
	}else{
		steps = abs(dy);
	}
	if (steps !=0)
	{
		x_inc = dx/(float)steps;
		y_inc = dy/(float)steps;
		for (int i = 0; i < steps; i++)
		{
			write_pixel( x, y, 1.0);
			x += x_inc;
			y += y_inc;
		}
	}
}

void Line::dda(const Point& p1, const Point& p2){
	int dx = p2.x - p1.x; // represent the difference for x between two points
	int dy = p2.y - p1.y; // represent the difference for y between two points
	int steps = 0;
	float x_inc = 0, y_inc = 0;
	float x = p1.x, y = p1.y;//record the current position for x and y during drawing the line.

	if (abs(dx)>=abs(dy))
	{
		steps = abs(dx);
	}else{
		steps = abs(dy);
	}

	x_inc = dx/(float)steps;
	y_inc = dy/(float)steps;
	for (int i = 0; i < steps; i++)
	{
		write_pixel( x, y, 1.0);
		x += x_inc;
		y += y_inc;
	}
}
/***************************************************************************/
void init_window()
/* Clear the image area, and set up the coordinate system */
{

	/* Clear the window */
	glClearColor(0.0, 0.0, 0.0, 0.0);
	glShadeModel(GL_SMOOTH);
	glOrtho(0, WIDTH, 0, HEIGHT, -1.0, 1.0);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); // Clear Screen
}

/***************************************************************************/

void display(void) // Create The Display Function
{	
	// glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); // Clear Screen
	write_pixel(x_last, y_last, 1.0); //<-you can get rid of this call if you like
	// CALL YOUR CODE HERE
	int last_pos = 2; // point to the last potision of point list
	int second_last_pos = points.size() - 1;
	if (points.size()>=2 && Line::isDrawed)
	{
		if (points.size() %2 == 0)
			if (second_last_pos != last_pos)
			{
				last_pos = points.size();
			}
		{
			
		}
		for (int i = last_pos; i >=2; i-=2)
		{
			Line::dda(points[i-1],points[i-2]);
		}
		
	}
	glutSwapBuffers(); // Draw Frame Buffer
}

/***************************************************************************/
void mouse(int button, int state, int x, int y)
{
	/* This function I finessed a bit, the value of the printed x,y should
   match the screen, also it remembers where the old value was to avoid multiple
   readings from the same mouse click.  This can cause problems when trying to
   start a line or curve where the last one ended */
	static int oldx = 0;
	static int oldy = 0;
	int mag;

	y *= -1;  //align y with mouse
	y += 500; //ignore
	mag = (oldx - x) * (oldx - x) + (oldy - y) * (oldy - y);
	if (mag > 20)
	{
		printf(" x,y is (%d,%d)\n", x, y);
		points.push_back(Point(x,y));
		std::cout<<"current points list size: "<<points.size()<< std::endl;
	}
	oldx = x;
	oldy = y;
	x_last = x;
	y_last = y;
	// std::cout<<"x1: "<<oldx<<", "<<"y1: "<<oldy<<std::endl;
	// std::cout<<"x2: "<<x_last<<", "<<"y2: "<<y_last<<std::endl;
}

/***************************************************************************/
void keyboard(unsigned char key, int x, int y) // Create Keyboard Function
{

	switch (key)
	{
	case 27:	 // When Escape Is Pressed...
		exit(0); // Exit The Program
		break;
	case '1': // stub for new screen
		printf("New screen\n");
		break;
	case 'l':
		Line::isDrawed = true;
	case 'd':
		if (Line::isDrawed)
		{
			Line::isDrawed = false;
		}else{
			Line::isDrawed = true;
		}
		
	default:
		break;
	}
}
/***************************************************************************/

int main(int argc, char *argv[])
{
	/* This main function sets up the main loop of the program and continues the
   loop until the end of the data is reached.  Then the window can be closed
   using the escape key.						 
    */

	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
	glutInitWindowSize(500, 500);
	glutCreateWindow("Computer Graphics");
	glutIdleFunc(display);
	glutDisplayFunc(display);
	glutMouseFunc(mouse);
	glutKeyboardFunc(keyboard);

	init_window(); //create_window

	glutMainLoop(); // Initialize The Main Loop
}
