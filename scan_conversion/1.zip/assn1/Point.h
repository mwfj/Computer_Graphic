class Point{
public:
	Point();
	~Point(){};
	Point &operator=(const Point &p);
	Point(int x1, int y1);
	bool operator==(const Point &p);
	bool operator!=(const Point &p);
	int x;
	int y;
};

Point::Point():x(1),y(1)
{}

Point::Point(int x1, int y1):x(x1), y(y1)
{}

Point &Point::operator=(const Point &p){
	this->x = p.x;
	this->y = p.y;
	return *this;
}

bool Point::operator==(const Point &p){
	if (this->x ==p.x && this->y == p.y){
		return true;
	}
	return false;
}

bool Point::operator!=(const Point &p){

	if (this->x != p.x || this->y != p.y){
		return true;
	}
	return false;
}