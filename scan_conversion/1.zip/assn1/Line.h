#include "Point.h"
class Line{
public:
    static bool isDrawed;
    static void dda(const Point&, const Point&);
};
